import os
import shutil

# Thư mục nguồn và đích
src_folder = r"D:\B3\Introduction to DL\datasetfinal\Bumblefoot1\train\Bumblefoot"
dst_folder = r"D:\B3\Introduction to DL\datasetfinal\BB-Final"

# Lấy danh sách file có chứa "bubblefoot" (không phân biệt hoa/thường)
files = [
    f for f in os.listdir(src_folder)
    if f.lower().endswith('.jpg') and "bubblefoot" in f.lower()
]
files.sort()  # Sắp xếp để copy có thứ tự

# Tìm số thứ tự cao nhất trong BB-Final
existing = [
    f for f in os.listdir(dst_folder)
    if f.lower().startswith('bb') and f.lower().endswith('.jpg')
]
numbers = [int(f[2:-4]) for f in existing if f[2:-4].isdigit()]
start_num = max(numbers) + 1 if numbers else 1

# Copy + đổi tên
for i, fname in enumerate(files, start=start_num):
    src_path = os.path.join(src_folder, fname)
    new_name = f"BB{i}.jpg"
    dst_path = os.path.join(dst_folder, new_name)
    shutil.copy(src_path, dst_path)
    print(f"✅ Copied {fname} → {new_name}")

print(f"Hoàn tất sao chép {len(files)} ảnh có chữ 'bubblefoot'!")
